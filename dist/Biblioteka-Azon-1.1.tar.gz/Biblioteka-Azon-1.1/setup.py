from setuptools import setup, find_packages

setup(
    name='Biblioteka-Azon',
    version='1.1',
    packages=find_packages(exclude=['tests*']),
    license='MIT',
    description='bilbioteka umozliwiajaca prace z zasbami azon',
    url='https://github.com/235076/Biblioteka-Azon',
    author='Mikolaj Sikorski',
    author_email='235076@student.pwr.edu.pl'
)