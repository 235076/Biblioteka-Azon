def hello():
    print("hello world!, ale juz v0.2")
