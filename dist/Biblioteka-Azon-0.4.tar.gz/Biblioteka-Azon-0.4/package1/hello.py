def hello():
    print("hello world! nowsza wersja!")
