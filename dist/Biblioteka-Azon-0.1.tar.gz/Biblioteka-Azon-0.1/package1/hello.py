def hello():
    print("hello!")
