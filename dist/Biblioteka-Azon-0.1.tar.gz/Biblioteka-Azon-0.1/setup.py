from setuptools import setup, find_packages

setup(
    name='Biblioteka-Azon',
    version='0.1',
    packages=find_packages(exclude=['tests*']),
    license='MIT',
    description='bilbioteka umozliwiajaca prace z zasbami azon',
    url='https://git.e-science.pl/msikorski235076_dpp/python_pip',
    author='Mikolaj Sikorski',
    author_email='235076@student.pwr.edu.pl'
)