def hello():
    print("hello world!, ale juz v1.0")
